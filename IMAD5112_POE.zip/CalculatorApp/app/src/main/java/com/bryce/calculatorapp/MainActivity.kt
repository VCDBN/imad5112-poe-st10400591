package com.bryce.calculatorapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    // Declare UI elements
    private lateinit var number1EditText: EditText
    private lateinit var number2EditText: EditText
    private lateinit var additionButton: Button
    private lateinit var subtractionButton: Button
    private lateinit var multiplicationButton: Button
    private lateinit var divisionButton: Button
    private lateinit var squareRootButton: Button
    private lateinit var powerButton: Button
    private lateinit var resultTextView: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Button to open StatisticsActivity
        val statsButton: Button = findViewById(R.id.statsButton)
        statsButton.setOnClickListener {
            val intent = Intent(this, StatsActivity::class.java)
            startActivity(intent)
        }

        // Initialize UI elements
        number1EditText = findViewById(R.id.number1EditText)
        number2EditText = findViewById(R.id.number2EditText)
        additionButton = findViewById(R.id.additionButton)
        subtractionButton = findViewById(R.id.subtractionButton)
        multiplicationButton = findViewById(R.id.multiplicationButton)
        divisionButton = findViewById(R.id.divisionButton)
        squareRootButton = findViewById(R.id.squareRootButton)
        powerButton = findViewById(R.id.powerButton)
        resultTextView = findViewById(R.id.resultTextView)



        // Set click listeners for operation buttons
        additionButton.setOnClickListener {
            performOperation("+")
        }

        subtractionButton.setOnClickListener {
            performOperation("-")
        }

        multiplicationButton.setOnClickListener {
            performOperation("*")
        }

        divisionButton.setOnClickListener {
            performOperation("/")
        }

        squareRootButton.setOnClickListener {
            performOperation("√")
        }

        powerButton.setOnClickListener {
            performOperation("^")
        }
    }

    // Function to perform arithmetic operations
    @SuppressLint("SetTextI18n")
    private fun performOperation(operation: String) {
        // Get user input from EditText fields
        val number1Str = number1EditText.text.toString()
        val number2Str = number2EditText.text.toString()

        // Check if the input is empty
        if (number1Str.isEmpty() || number2Str.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show()
            return
        }

        // Parse user input to double (or show an error if invalid)
        val number1 = number1Str.toDoubleOrNull()
        val number2 = number2Str.toDoubleOrNull()

        if (number1 == null || number2 == null) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show()
            return
        }

        // Check the selected operation
        val result = when (operation) {
            "+" -> number1 + number2
            "-" -> number1 - number2
            "*" -> number1 * number2
            "/" -> {
                // Check for division by zero
                if (number2 == 0.0) {
                    Toast.makeText(this, "Division by zero is not allowed", Toast.LENGTH_SHORT).show()
                    return
                }
                number1 / number2
            }
            "√" -> {
                // Check for negative square root
                if (number1 < 0) {
                    val sqrtResult = sqrt(-number1)
                    "$sqrtResult i" // Display as imaginary number
                } else {
                    sqrt(number1)
                }
            }
            "^" -> {
                // Calculate power using a loop
                var result = 1.0
                for (i in 1..number2.toInt()) {
                    result *= number1
                }
                result
            }
            else -> {
                Toast.makeText(this, "Invalid operation", Toast.LENGTH_SHORT).show()
                return
            }
        }

        // Display the result in the TextView
        resultTextView.text = "Result: $result"
    }
}

