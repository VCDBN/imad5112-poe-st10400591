package com.bryce.calculatorapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class StatsActivity : AppCompatActivity() {

    // Define array to store entered numbers
    private val numbers = IntArray(10)
    private var count = 0 // To keep track of how many numbers have been entered

    // Declare UI elements
    private lateinit var arrayTV: TextView
    private lateinit var clearBTN: Button
    private lateinit var averageBTN: Button
    private lateinit var minMaxBTN: Button
    private lateinit var enterNumET: EditText
    private lateinit var enterNumBTN: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        // Button to return to main screen
        val backBTN: Button = findViewById(R.id.backBTN)
        backBTN.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Initialize UI elements
        arrayTV = findViewById(R.id.arrayTV)
        clearBTN = findViewById(R.id.clearBTN)
        averageBTN = findViewById(R.id.averageBTN)
        minMaxBTN = findViewById(R.id.minMaxBTN)
        enterNumET = findViewById(R.id.enterNumET)
        enterNumBTN = findViewById(R.id.enterNumBTN)


        // Set click listeners for buttons
        clearBTN.setOnClickListener { clearNumbers() }
        averageBTN.setOnClickListener { calculateAverage() }
        minMaxBTN.setOnClickListener { findMinMax() }
        enterNumBTN.setOnClickListener { enterNumber() }
    }

    private fun enterNumber() {
        val userInput = enterNumET.text.toString()
        if (userInput.isNotEmpty()) {
            val enteredNumber = userInput.toInt()
            if (count < numbers.size) {
                numbers[count] = enteredNumber
                count++
                updateDisplay()
                enterNumET.text.clear() // Clear the input field
            } else {
                displayResult("Cannot enter more than ${numbers.size} numbers.")
            }
        } else {
            displayResult("Please enter a valid number.")
        }
    }

    private fun clearNumbers() {
        // Clear the array and reset count
        numbers.fill(0)
        count = 0
        updateDisplay()
    }

    private fun calculateAverage() {
        // Calculate and display the average
        if (count > 0) {
            val sum = numbers.take(count).sum()
            val average = sum.toDouble() / count
            displayResult("Average: %.2f".format(average))
        } else {
            displayResult("No numbers entered.")
        }
    }

    private fun findMinMax() {
        // Find and display the min & max values
        if (count > 0) {
            val min = numbers.take(count).minOrNull()
            val max = numbers.take(count).maxOrNull()
            displayResult("Minimum: $min, Maximum: $max")
        } else {
            displayResult("No numbers entered.")
        }
    }

    private fun displayResult(result: String) {
        // Display the result
        arrayTV.text = result
    }

    private fun updateDisplay() {
        // Display the entered numbers in the array
        val displayText = if (count > 0) {
            "Numbers entered: ${numbers.take(count).joinToString(", ")}"
        } else {
            "No numbers entered."
        }
        arrayTV.text = displayText
    }
}